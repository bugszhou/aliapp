## {{ name }}
----------------------------
author: {{ author }} <br>
description: {{ description }}

<br>
###配置说明：
<br>
####1. ./docs --- 项目文档<br>
|--api.md --- 更改为项目接口文档

开发
====
appid：<br>
componentid: <br>

接口
====
[接口文档](./docs/api.md)
