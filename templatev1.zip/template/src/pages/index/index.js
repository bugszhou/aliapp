let app = getApp();
Page({
    data: {},
    onLoad(opts) {
    },
    onShow() {},
    onUnload() {}
});
