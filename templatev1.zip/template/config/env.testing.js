module.exports = {
    API_ENV: JSON.stringify('testing')
};