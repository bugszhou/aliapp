module.exports = {
    API_ENV: JSON.stringify('production')
};