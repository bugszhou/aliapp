module.exports = {
    API_ENV: JSON.stringify('development')
};