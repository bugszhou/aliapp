module.exports = {
    globalVariable: ['App', 'Page', 'getApp', 'my'],
    xmlType: /\.(wxml|axml|swan)(\?.*)?$/
};